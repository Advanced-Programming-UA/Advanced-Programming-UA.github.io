var searchData=
[
  ['is_5frotating',['is_rotating',['../class_o_demo_1_1_wheel.html#a843e4b1ec1926578cc8aa95613b4f734',1,'ODemo::Wheel']]],
  ['is_5frunning',['is_running',['../class_o_demo_1_1_engine.html#ac33ad9c836b493b058ac185652912eac',1,'ODemo::Engine::is_running()'],['../class_o_demo_1_1_motorcycle.html#afb779212637d9b6649d6d068af6633a3',1,'ODemo::Motorcycle::is_running()'],['../class_o_demo_1_1_unicycle.html#aa25b2435fcc605f593c30105ad5127c7',1,'ODemo::Unicycle::is_running()']]]
];
