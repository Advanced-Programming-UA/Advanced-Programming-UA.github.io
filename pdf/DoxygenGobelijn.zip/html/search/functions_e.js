var searchData=
[
  ['vbasics',['vbasics',['../demos_8h.html#abdac968175c91e4f9961096ab70882ab',1,'vbasics():&#160;vbasics.cpp'],['../vbasics_8cpp.html#abdac968175c91e4f9961096ab70882ab',1,'vbasics():&#160;vbasics.cpp']]],
  ['vpoly',['vpoly',['../demos_8h.html#aeec2ca178e0b599d42c8fa32d47813aa',1,'vpoly():&#160;vpoly.cpp'],['../vpoly_8cpp.html#aeec2ca178e0b599d42c8fa32d47813aa',1,'vpoly():&#160;vpoly.cpp']]]
];
